package ServerContainer;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Server {
	static ServletRequest req = null;
	static ServletResponse res = null;
	
	public static void main(String args[]) throws Exception{
		final int port = 3333; 
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(port);
			println("鏈嶅姟鍣ㄦ鍦ㄧ洃瑙嗙鍙ｏ細 " + serverSocket.getLocalPort());
			
			while(true){
				Socket clientSocket = serverSocket.accept();
				println("寤虹珛浜嗕笌瀹㈡埛鐨勪竴涓柊鐨凾CP杩炴帴锛岃瀹㈡埛鐨勫湴鍧�负锛�" + clientSocket.getInetAddress() +" : " + clientSocket.getPort());
				
				service(clientSocket);
				//clientSocket.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void service(Socket socket) throws Exception{
		try {
			InputStream socketIn = socket.getInputStream();
			//Thread.sleep(500);
			req = new MyServletRequest(socketIn);
			println("姝ｅ湪鍒涘缓ServletRequest瀵硅薄");
			OutputStream socketOut = socket.getOutputStream();
			res = new MyServletResponse(socketOut);
			println("姝ｅ湪鍒涘缓ServletResponse瀵硅薄");
			ServletProcessor.processServletRequest((MyServletRequest)req, (MyServletResponse)res); 
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void println(String content){
		System.out.println(content);
	}
}
