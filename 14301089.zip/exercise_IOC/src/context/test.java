package context;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassPathXMLApplicationContext path = new ClassPathXMLApplicationContext("configAnnotation.xml");
		Service_implement userService = (Service_implement) path.getBean("userService");
		userService.show();
	}

}
