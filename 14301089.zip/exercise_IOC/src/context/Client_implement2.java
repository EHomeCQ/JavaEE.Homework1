package context;

@Content(id="userDao")
public class Client_implement2 {
	
String name ;  
    
    public void message(){  
        System.out.println("The method of client2!");  
    }

}
