package context;

@Content(id = "userService")
public class Service_implement {

	
	private Client_implement1 c1;
	private Client_implement2 c2;
	
	
	@Autolink(name = "userDao")
	public void setUserDao(Client_implement2 client) {
		this.c2 = client;
	}

	// set�����ϵ�ע�⣬û������name����
	@Autolink
	public void setUser1Dao(Client_implement1 client) {
		this.c1 = client;
	}

	public void show() {
		
		c2.message();
		c1.message();
		System.out.println("The method of service!");
	}
}
