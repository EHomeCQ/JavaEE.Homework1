package context;

@Content
public class Client_implement1 {
	String name;

	public void message(){  
        System.out.println("The method of client1!");
	}
}
