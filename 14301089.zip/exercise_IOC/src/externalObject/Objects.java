package externalObject;

import bean.BeanDefinition;

public interface Objects {
	
	Object getBean(String Name);
	
	void registerBeanDefinition(String Name, BeanDefinition Definition);
}
