package test;

public class Person {
	
	
	private String name;
	private String nickname;
	
	private Family family;
	
	
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public Family getFamily() {
		return family;
	}
	
	public void setFamily(Family family) {
		this.family = family;
	}
	
	public String printDishes()
	{
		return String.format("The  car is: %s. Color is: %s." ,getName(),getNickname());
	}
}
