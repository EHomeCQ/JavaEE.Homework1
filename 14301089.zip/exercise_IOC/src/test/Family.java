package test;

public class Family {
   private String family_id;

	public String getFamilyId() {
		return family_id;
	}
	
	public void setFamilyId(String family_id) {
		this.family_id = family_id;
	}
	public String P(){
		return "family: " +family_id;
	}

}
