package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import externalObject.Objects;
import externalObject.ObjectXML;
import resource.GetFile;

public class Component {

	public static void main(String[] args) {
		GetFile resource = new GetFile("beans.xml");

		Objects beanFactory = new ObjectXML(resource);
		// the BeanDefinition doesn`t create the real bean yet
		Dishes d = (Dishes) beanFactory.getBean("egg dishes");
		Person c = (Person) beanFactory.getBean("car");
		Family o = (Family) beanFactory.getBean("office");
		System.out.println(d.printDishes() + d.getCar().printDishes() + d.getCar().getFamily().P());
		System.out.println(c.printDishes() + c.getFamily().P());
		System.out.println(o.P());

	}
}
