package bean;

import java.util.ArrayList;
import java.util.List;

public class Properties {
	private List<Property> propertyValues = new ArrayList<Property>();
	public void AddPropertyValue(Property propertyValue){
		propertyValues.add(propertyValue);
	}
	public List<Property> GetPropertyValues()
	{
		return propertyValues;
	}
}
