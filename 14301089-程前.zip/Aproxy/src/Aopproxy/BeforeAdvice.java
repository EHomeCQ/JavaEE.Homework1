package Aopproxy;

public interface BeforeAdvice extends Advice {
}
