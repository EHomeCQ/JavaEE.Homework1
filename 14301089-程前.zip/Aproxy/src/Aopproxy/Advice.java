package Aopproxy;

public interface Advice {

}
